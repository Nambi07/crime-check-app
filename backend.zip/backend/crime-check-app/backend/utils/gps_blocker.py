def block_location(location):
    print(f"[GPS BLOCKER] Blocking location: {location} from further transactions")
